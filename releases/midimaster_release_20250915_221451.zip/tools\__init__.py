"""
Tools package for utility scripts.

Enables module execution via:
  python -m tools.backfill_patterns
"""