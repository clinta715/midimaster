"""
Examples package for MIDI Master.
"""