"""
ML Insights package for music analysis and genre classification.
"""