"""
Documentation package for MIDI Master.
"""