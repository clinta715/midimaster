"""
Genre demo examples for MIDI Master.
"""